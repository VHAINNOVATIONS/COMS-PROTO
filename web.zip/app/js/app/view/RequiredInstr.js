Ext.define("COMS.view.RequiredInstr", {
	"extend": "Ext.Component",
	"alias": "widget.RequiredInstr",
	"cls" : "RequiredInstr",
	"html": "Fields with an <em class=\"required-field\">*</em> are required fields"
});

