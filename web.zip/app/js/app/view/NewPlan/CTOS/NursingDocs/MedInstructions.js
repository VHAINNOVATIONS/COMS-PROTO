Ext.define("COMS.view.NewPlan.CTOS.NursingDocs.MedInstructions", {
	"extend": "Ext.container.Container",
	"alias": "widget.MedInstructions",
	"id": "CTOS.ND.MedInstructions",
	"hidden": true,
	"defaults": { "labelAlign": "right", "labelWidth": 200, "labelClsExtra": "NursingDocs-label" },
	"items": [

	]
});