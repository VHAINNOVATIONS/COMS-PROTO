Ext.define('COMS.view.NewPlan.DiagImage' ,{
    extend: 'Ext.panel.Panel',
    alias : 'widget.DiagImage',
	name : 'Patient Diagnostic Imaging History',

	autoEl : { tag : 'section' },
	cls : 'xPandablePanel',

	collapsible : true,
	collapsed : true,
	title : 'Diagnostic Imageing',
	html: '<h2 class=\'Development\'>To Be Developed</h2>'
});