Ext.define("COMS.view.Common.EmeticInfo" ,{
	"extend" : "Ext.Component",
	"alias" : "widget.EmeticInfo",
	"name" : "EmeticInfo",
	margin: 10,
	border: 0,
	style: {
		borderColor: '#99bce8',
		borderStyle: 'solid'
	}
});
