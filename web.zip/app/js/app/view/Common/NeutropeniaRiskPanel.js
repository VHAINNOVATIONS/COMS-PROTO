Ext.define("COMS.view.Common.NeutropeniaRiskPanel",{
	"extend" : "Ext.panel.Panel",
	"alias" : "widget.NeutropeniaRiskPanel",
	"title" : "Neutropenia Risk - "
});
