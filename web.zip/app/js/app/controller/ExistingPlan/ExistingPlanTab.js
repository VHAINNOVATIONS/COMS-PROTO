Ext.define('COMS.controller.ExistingPlan.ExistingPlanTab', {
	extend : 'Ext.app.Controller',
	views : [ 'ExistingPlan.ExistingPlanTab' ]
});