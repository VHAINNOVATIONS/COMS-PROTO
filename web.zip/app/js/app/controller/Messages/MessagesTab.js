Ext.define("COMS.controller.Messages.MessagesTab", {
	extend : "Ext.app.Controller",
	views : [ "Messages.MessagesTab" ],
// INLINE FOR TESTING: 	models : ["Messages"],
// INLINE FOR TESTING: 	stores : ["Messages"],
    init: function () {
        wccConsoleLog('Initialized Messages Tab Panel Controller!');
	}
});