Ext.define("COMS.controller.Common.DEMOpuWin", {
	extend : "Ext.app.Controller",
	views : [ "NewPlan.CTOS.FS_Toxicity", "Management.EmeticMeds" ]
});