Ext.define("COMS.store.FluidType", {
	extend : "Ext.data.Store",
	model : "COMS.model.LookupTable_FluidType"
});