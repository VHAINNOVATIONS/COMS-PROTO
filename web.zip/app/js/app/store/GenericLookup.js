Ext.define("COMS.store.GenericLookup", {
	extend : "Ext.data.Store",
	model : "COMS.model.GenericLookupModel"
});