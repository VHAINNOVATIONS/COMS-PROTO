Ext.define('COMS.store.CycleLengthMax', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.CycleLengthMax
});