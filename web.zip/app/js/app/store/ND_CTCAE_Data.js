Ext.define("COMS.store.ND_CTCAE_Data", {
	extend : "Ext.data.Store",
	model : Ext.COMSModels.ND_CTCAE_Data
});