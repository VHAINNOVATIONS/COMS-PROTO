Ext.define("COMS.store.MedReminders", {
	extend : "Ext.data.Store",
	model : Ext.COMSModels.MedReminder
});