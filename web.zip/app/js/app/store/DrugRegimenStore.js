Ext.define('COMS.store.DrugRegimenStore', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.DrugRegimen
});