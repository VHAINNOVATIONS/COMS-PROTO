Ext.define('COMS.store.PatientCumulativeDosing', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.PatientCumulativeDosing
});