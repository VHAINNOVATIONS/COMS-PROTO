Ext.define('COMS.store.TimeFrameUnit', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.TimeFrameUnit
});