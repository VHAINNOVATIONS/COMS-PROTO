Ext.define('COMS.store.Template', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.Template
});