Ext.define('COMS.store.CycleLengthStore', {
    extend : 'Ext.data.Store',
    model : Ext.COMSModels.CycleLengthStore
});