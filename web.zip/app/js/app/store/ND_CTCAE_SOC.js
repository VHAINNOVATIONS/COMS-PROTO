Ext.define("COMS.store.ND_CTCAE_SOC", {
	extend : "Ext.data.Store",
	model : Ext.COMSModels.ND_CTCAE_SOC
});