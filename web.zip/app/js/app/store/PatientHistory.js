Ext.define('COMS.store.PatientHistory', {
	extend : 'Ext.data.Store',
	model : 'COMS.model.PatientHistory'
});