Ext.define('COMS.store.ReferencesStore', {
    extend : 'Ext.data.Store',
    model : 'COMS.model.LookupModel'
});