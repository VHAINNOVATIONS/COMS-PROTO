Ext.define("COMS.store.FlowSheetCombo", {
	"extend" : "Ext.data.Store",
	"fields" : ["label", "cols", "Cycle", "StartDate", "StartDay", "StartIdx", "EndDate", "EndDay", "EndIdx"]
});
