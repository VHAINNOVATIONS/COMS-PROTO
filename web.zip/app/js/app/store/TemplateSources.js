Ext.define('COMS.store.TemplateSources', {
	extend : 'Ext.data.Store',
    autoLoad: false,
	model : Ext.COMSModels.TemplateSources
});
