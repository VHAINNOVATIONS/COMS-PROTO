Ext.define('COMS.store.EmetogenicLevel', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.EmetogenicLevel
});