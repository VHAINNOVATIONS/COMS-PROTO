Ext.define('COMS.store.PreHydrationStore', {
    extend : 'Ext.data.Store',
    model : 'COMS.model.PreHydrationModel'
});