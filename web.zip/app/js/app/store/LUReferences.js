Ext.define('COMS.store.LUReferences', {
    extend : 'Ext.data.Store',
    model : Ext.COMSModels.LUReferences
});