Ext.define('COMS.model.MedDocs', {
	extend: 'Ext.data.Model',
	fields: ["ID", "Med_ID", "MedName", "Documentation"]
});