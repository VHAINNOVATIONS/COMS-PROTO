Ext.define('COMS.model.ClinicInfo', {
	extend: 'Ext.data.Model',
	fields: ["ID", "Label", "Details"]
});
