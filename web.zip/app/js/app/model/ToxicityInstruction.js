Ext.define('COMS.model.ToxicityInstruction', {
	extend: 'Ext.data.Model',
	fields: ["ID", "Label", "Details"]
});
