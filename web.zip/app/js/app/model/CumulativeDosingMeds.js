Ext.define('COMS.model.CumulativeDosingMeds', {
	extend: 'Ext.data.Model',
	fields: ["MedName", "CumulativeDoseAmt", "UnitsID", "ID", "CumulativeDoseUnits", "MedID"]
});