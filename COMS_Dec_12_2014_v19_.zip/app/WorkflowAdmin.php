<?php
include "workflow.php";
echo "Admin Workflow<br><br>";

$ReasonNo = 6;
$NoSteps = 3;

UpdateWorkflowSteps($ReasonNo,$NoSteps);




?>