<?php
    echo "<form method='get' action='search_templates.php'><input type='text' id='q' name='q'/><input type='submit' value='Search Templates' /></form>";	 
?>