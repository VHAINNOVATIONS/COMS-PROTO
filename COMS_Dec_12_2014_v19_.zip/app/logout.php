<?php	
include "session.php";
sessionkill();
?>