<?php

include "session.php";
include "workflow.php";
$mid = $_GET['mid'];

ForwardMessage($mid);



?>