<?php

echo "<table><tr><td>" .
     "&nbsp;&nbsp;&nbsp;&nbsp;".
	 "<a href='index.php'>Main</a>".
	 ".&nbsp;&nbsp;&nbsp;&nbsp;".
	 "</td></tr></table>";

?>