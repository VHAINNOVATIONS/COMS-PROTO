Ext.define('COMS.controller.KnowledgeBase.KnowledgeBaseTab', {
    extend : 'Ext.app.Controller',
	views : [ 'KnowledgeBaseTab' ]
});