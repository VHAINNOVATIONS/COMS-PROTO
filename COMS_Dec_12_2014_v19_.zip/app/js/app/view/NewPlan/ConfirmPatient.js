Ext.define("COMS.view.NewPlan.ConfirmPatient" ,{
	extend: "Ext.container.Container",
	alias : "widget.ConfirmPatient",
	name : "Confirm Patient Control",

	html: "Click on Patient from <abbr title=\"Computerized Patient Record System\">CPRS</abbr>",
	hidden : true
});