Ext.define('COMS.view.NewPlan.Pharmacy' ,{
    extend: 'Ext.panel.Panel',
    alias : 'widget.Pharmacy',
	name : 'Patient Pharmacological History',

	autoEl : { tag : 'section' },
	cls : 'xPandablePanel',

	collapsible : true,
	collapsed : true,
	title : 'Pharmacy',
	html: '<h2 class=\'Development\'>To Be Developed</h2>'
});