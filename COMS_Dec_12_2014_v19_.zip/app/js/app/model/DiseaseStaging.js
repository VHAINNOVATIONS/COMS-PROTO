Ext.define("COMS.model.DiseaseStaging", {
	extend: "Ext.data.Model",
	fields: ["ID", "DiseaseID", "Disease", "Stage"]
});
