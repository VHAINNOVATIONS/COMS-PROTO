Ext.define("COMS.model.IDEntry", {
	extend: "Ext.data.Model",
	fields: ["Vital2Check", "MinMax", "MinValue", "MaxValue", "MinMaxMsg", "PctVarFromValue", "PctVarFromValuePct", "PctVarFromValueValue", "PctVarFromValueMsg", "PctVarFromLast", "PctVarFromLastPct", "PctVarFromLastMsg"]
});
