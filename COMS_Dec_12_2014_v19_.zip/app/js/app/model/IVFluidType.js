Ext.define('COMS.model.IVFluidType', {
	extend: 'Ext.data.Model',
	fields: ["Med_ID", "FluidType_ID", "MedName", "FluidType"]
});
