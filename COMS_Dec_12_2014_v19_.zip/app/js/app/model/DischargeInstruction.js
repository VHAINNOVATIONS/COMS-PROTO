Ext.define('COMS.model.DischargeInstruction', {
	extend: 'Ext.data.Model',
	fields: ["ID", "Label", "Details"]
});
