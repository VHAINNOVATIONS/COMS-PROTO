Ext.define('COMS.model.References', {
	extend: 'Ext.data.Model',
	fields: [
		{ name: 'id', type: 'string'},
		{ name: 'Reference', type: 'string'},
		{ name: 'ReferenceLink', type: 'string'}
	]
});
