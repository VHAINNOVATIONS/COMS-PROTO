Ext.define('COMS.model.MedRisks', {
	extend: 'Ext.data.Model',
	fields: ["ID", "Label", "Details"]
});
