Ext.define('COMS.store.TemperatureLocation', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.TemperatureLocation
});