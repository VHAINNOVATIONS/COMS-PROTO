Ext.define('COMS.store.ChemoHistory', {
	extend : 'Ext.data.Store',
	model : 'COMS.model.ChemoHistory'
});