Ext.define('COMS.store.RadHistory', {
	extend : 'Ext.data.Store',
	model : 'COMS.model.RadHistory'
});