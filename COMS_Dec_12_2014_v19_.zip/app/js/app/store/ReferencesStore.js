Ext.define('COMS.store.ReferencesStore', {
    extend : 'Ext.data.Store',
    model : Ext.COMSModels.References
});