Ext.define('COMS.store.DrugUnitsStore', {
    extend : 'Ext.data.Store',
    model : Ext.COMSModels.DrugUnits,
	autoLoad: true
});