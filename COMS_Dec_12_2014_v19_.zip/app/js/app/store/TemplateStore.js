Ext.define('COMS.store.TemplateStore', {
    extend : 'Ext.data.Store',
    model : 'COMS.model.TemplateModel'
});