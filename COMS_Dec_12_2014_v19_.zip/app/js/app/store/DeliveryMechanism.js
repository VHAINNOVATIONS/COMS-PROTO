Ext.define('COMS.store.DeliveryMechanism', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.DeliveryMechanism
});