Ext.define("COMS.store.Templates", {
	"extend" : "Ext.data.Store",
	"autoLoad" : false,
	"model" : Ext.COMSModels.Templates,
	"autoDestroy" : true
});