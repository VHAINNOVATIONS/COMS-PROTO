Ext.define('COMS.store.PostHydrationStore', {
    extend : 'Ext.data.Store',
    model : 'COMS.model.PostHydrationModel'
});