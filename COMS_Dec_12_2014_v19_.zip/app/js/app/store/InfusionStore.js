Ext.define('COMS.store.InfusionStore', {
	extend : 'Ext.data.Store',
	model : Ext.COMSModels.Infusion,
	autoLoad: true
});