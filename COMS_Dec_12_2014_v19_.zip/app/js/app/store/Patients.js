Ext.define('COMS.store.Patients', {
	extend : 'Ext.data.Store',
	model : 'COMS.model.PatientInfo'
});