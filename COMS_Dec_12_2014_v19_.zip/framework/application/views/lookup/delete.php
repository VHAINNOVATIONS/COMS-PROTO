<?php

    echo "{\"success\": true, \"msg\": \"Record Deleted.\" , \"records\":[{\"id\":\"".$savedid."\",\"value\":\"".$savedname.
          "\",\"description\":\"".$savedescription."\"}]}"; 

?>
