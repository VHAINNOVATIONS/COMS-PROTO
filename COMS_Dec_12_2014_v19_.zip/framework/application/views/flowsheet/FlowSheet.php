<?php
    echo json_encode($jsonRecord);
?>
